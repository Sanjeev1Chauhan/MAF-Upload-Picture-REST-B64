/* Copyright (c) 2011, 2012, Oracle and/or its affiliates. All rights reserved. */
/* ------------------------------------------------------ */
/* ------------------- ADFInfoBundle_zh_CN.js ---------------------- */
/* ------------------------------------------------------ */
// AUTO-GENERATED FILE
// since this gets loaded programmatically, adf.mf.resource will already be defined

adf.mf.resource.ADFInfoBundle_zh_CN={
"WARN_SKIP_REMOTE_WRITE":"\u7531\u4e8e java \u4e0d\u53ef\u7528, \u56e0\u6b64\u5c06\u8df3\u8fc7\u8fdc\u7a0b\u5199\u5165\u3002",
"LBL_WARNING_DISPLAY_STR":"\u8b66\u544a",
"WARN_MESSAGE_FOR_SELENIUM_TEST":"\u4f7f\u7528\u53c2\u6570\u6267\u884c Selenium \u6d4b\u8bd5\u7684\u8b66\u544a\u6d88\u606f: {0}",
"LBL_CONFIRMATION_DISPLAY_STR":"\u786e\u8ba4",
"LBL_INFO_DISPLAY_STR":"\u4fe1\u606f",
"WARN_PROCESSING_REMOVE_DATA_CHANGE":"\u5904\u7406 #\'\'{{0}.collectionModel\'\'} \u7684 (\u5220\u9664) \u6570\u636e\u66f4\u6539\u65f6\u9047\u5230\u95ee\u9898 - {1}",
"WARN_PROCESSING_UPDATE_DATA_CHANGE":"\u5904\u7406 #\'\'{{0}.collectionModel\'\'} \u7684 (\u66f4\u65b0) \u6570\u636e\u66f4\u6539\u65f6\u9047\u5230\u95ee\u9898 - {1}",
"LBL_OK_DISPLAY_STR":"\u786e\u5b9a",
"WARN_PROCESSING_CREATE_DATA_CHANGE":"\u5904\u7406 #\'\'{{0}.collectionModel\'\'} \u7684 (\u521b\u5efa) \u6570\u636e\u66f4\u6539\u65f6\u9047\u5230\u95ee\u9898 - {1}",
"LBL_FATAL_DISPLAY_STR":"\u81f4\u547d",
"WARN_PROCESSING_VAR_CHANGES":"\u5904\u7406\u53d8\u91cf\u66f4\u6539{0}\u65f6, processDataChangeEvent \u4e2d\u51fa\u9519",
"LBL_ERROR_DISPLAY_STR":"\u9519\u8bef",
"WARN_UNABLE_TO_FETCH_SET":"\u65e0\u6cd5\u63d0\u53d6\u96c6 - {0}",
"WARN_PURGING_CACHE":"\u5c1d\u8bd5\u6e05\u9664\u9ad8\u901f\u7f13\u5b58\u65f6\u51fa\u9519 - {0}",
"WARN_UPDATING_CACHE":"\u7531\u4e8e\u53d1\u751f\u6570\u636e\u66f4\u6539\u4e8b\u4ef6\u800c\u66f4\u65b0\u9ad8\u901f\u7f13\u5b58\u65f6\u9047\u5230\u95ee\u9898\u3002",
"WARN_PROCESSING_PROVIDER_CHANGES":"\u5904\u7406\u63d0\u4f9b\u65b9\u66f4\u6539{0}\u65f6, processDataChangeEvent \u4e2d\u51fa\u9519",
"oracle.core.ojdl.logging.MessageIdKeyResourceBundle":""
}
