/* Copyright (c) 2011, 2012, Oracle and/or its affiliates. All rights reserved. */
/* ------------------------------------------------------ */
/* ------------------- ADFInfoBundle_ro.js ---------------------- */
/* ------------------------------------------------------ */
// AUTO-GENERATED FILE
// since this gets loaded programmatically, adf.mf.resource will already be defined

adf.mf.resource.ADFInfoBundle_ro={
"WARN_SKIP_REMOTE_WRITE":"Deoarece Java nu este disponibil, scrierea de la distan\u0163\u0103 va fi omis\u0103.",
"LBL_WARNING_DISPLAY_STR":"Avertisment",
"WARN_MESSAGE_FOR_SELENIUM_TEST":"Mesaj de avertisment pt. testul Selenium cu argumentul: {0}",
"LBL_CONFIRMATION_DISPLAY_STR":"Confirmare",
"LBL_INFO_DISPLAY_STR":"Informa\u0163ii",
"WARN_PROCESSING_REMOVE_DATA_CHANGE":"A survenit o problem\u0103 la procesarea modific\u0103rii (elimin\u0103rii) datelor pt. #\'\'{{0}.collectionModel\'\'} - {1}",
"WARN_PROCESSING_UPDATE_DATA_CHANGE":"A survenit o problem\u0103 la procesarea modific\u0103rii (actualiz\u0103rii) datelor pt. #\'\'{{0}.collectionModel\'\'} - {1}",
"LBL_OK_DISPLAY_STR":"OK",
"WARN_PROCESSING_CREATE_DATA_CHANGE":"A survenit o problem\u0103 la procesarea modific\u0103rii (cre\u0103rii) datelor pt. #\'\'{{0}.collectionModel\'\'} - {1}",
"LBL_FATAL_DISPLAY_STR":"Fatal\u0103",
"WARN_PROCESSING_VAR_CHANGES":"Eroare la processDataChangeEvent \u00een timpul proces\u0103rii modific\u0103rilor variabilei: {0}",
"LBL_ERROR_DISPLAY_STR":"Eroare",
"WARN_UNABLE_TO_FETCH_SET":"Nu s-a putut prelua setul - {0}",
"WARN_PURGING_CACHE":"Eroare la \u00eencercarea de golire a cache-ului - {0}",
"WARN_UPDATING_CACHE":"A survenit o problem\u0103 la actualizarea cache-ului ca rezultat al evenimentului de modificare a datelor.",
"WARN_PROCESSING_PROVIDER_CHANGES":"Eroare la processDataChangeEvent \u00een timpul proces\u0103rii modific\u0103rilor furnizorului: {0}",
"oracle.core.ojdl.logging.MessageIdKeyResourceBundle":""
}
